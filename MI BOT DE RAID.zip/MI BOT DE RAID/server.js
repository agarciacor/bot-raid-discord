/**
 * 
 * BOT DE RAID PARA SERVIDORES DE DISCORD
 * 
 * Desarrollado por Alejandro Garcia
 * Programador y hacker etico
 * Discord: @AlejandroGarcia#7590
 * 
 * Uso para fines recreativos
 * 
 * Version: MinelordNonSecurity v2.0.0
 * Fecha de lanzamiento 29/octubre/2022
 * 
 */

//const express = require("express")
//const server = express();
const variables = require('./variables.json');
//const chalk = require('chalk');

//server.all("/", (req, res) => {
//  res.send("Creado por AlejandroGarcia#7590")
//});

function keepAlive() {

//  server.listen(3000, () => {
    console.log("\x1b[33m", 'Inicializando Servicios');
//    for(var i = 0; i <= 100; i++){
//    }
//  });
}

module.exports = keepAlive;